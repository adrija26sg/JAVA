#include <stdio.h>
int main()
{
	
	char a=128;
	unsigned char b=256;
	printf("%d %d", a , b);
	printf("\n");
return a;
}
