#include<stdio.h>
int main()
{
	int i=0;
	for(;i++; printf("%d",i));
	printf("%d", i);
}
