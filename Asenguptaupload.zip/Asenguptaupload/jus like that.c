#include<stdio.h>
int main()
{
	int i ,j, m,k ;
	printf("enter no of rows");
	scanf("%d", &m);
	int a= m-1;
	int no=2*i-1;
	for(i=1;i<=m;i++)
	{
		for(j=1;j<a;j++)
		{
			printf(" ");
		}
		for(k=1;k<=no;k++)
		{
			printf("*");
		}
		if(a>i)
		{
			a=a+1;
			no=no-2;
		}
		printf("\n");
	}
return 0;
}
