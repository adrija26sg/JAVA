#include<stdio.h>
int main()
{
	int no , revno=0 , rem , temp ;
	printf("enter an integer");
	scanf("%d", &no);
	temp=no;
	while(temp!=0)
	{
		rem=temp%10;
		revno=revno*10+rem;
		temp=temp/10;
	}
	if(revno==no)
	printf("is palindrome no");
	else 
	printf("no");
}
