#include <stdio.h>
int main()
{
	int no , sum=0,i ;
	printf("enter a number");
	scanf("%d", &no);
	int p=no*2;
	for( i=1;i<=no;i++)
	{
		if(no%i==0)
		sum=sum+i;
	}
	if(sum==p)
	printf(" complete number");
	else
	printf("not");
	
	return 0;
}
