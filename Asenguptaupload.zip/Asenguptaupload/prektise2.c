#include<stdio.h>
#include<math.h>
int main()
{
	int i,no,c=0; double sum=0.0;
	printf(" entera number");
	scanf("%d", &no);
	int a=no, b=no;
 while(no>0)
 {
 	int d=no%10;
 	c++;
 	no=no/10;
 	
 }
 while(a>=1)
 {
 	int p=a%10;
 	sum=sum+pow(p,c);
 	a=a/10;
 	
 }
 if((int)sum==b)
 printf("yes");
}
