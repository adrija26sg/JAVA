#include<stdio.h>
int main()
{
	int i , n , j=0;
	printf("enter a number ");
	scanf("%d" , &n);
	for(i=2;i<n;i++)
	{
		if(n%i==0)
		j++;
	}
	if(j==0)
	printf(" number is prime");
	else
	printf("number is not prime");
}
