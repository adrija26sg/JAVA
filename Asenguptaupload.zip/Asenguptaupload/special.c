//f the sum of the factorial of digits of a number (N) is equal to the number itself, the number (N) is called a special number.
#include<stdio.h>
int main()
{
	int i , no ,sum=0,a;
	printf(" enter a number ");
	scanf("%d", &no);
	a=no;
	while(no>0)
	{
		int d=no%10;
		int f=1;
		for(i=1;i<=d;i++)
	{
		f=f*i;
		
	}
	sum=sum+f;
	
	no=no/10;
		
	}
	
	if(sum==a){
	
	printf("special hell yeah!");}
	else{
	
	printf("stfu no");}
}
	
